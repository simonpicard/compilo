/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils.algorithms;

/**
 *
 * @author arnaud
 */
public interface GrammarAlgorithm {
    
    public abstract void process() throws Exception;
    
}
